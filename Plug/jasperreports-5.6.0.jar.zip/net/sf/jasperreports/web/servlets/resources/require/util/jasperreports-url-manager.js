/**
 * Created with IntelliJ IDEA.
 * User: narcis
 * Date: 1/29/14
 * Time: 5:42 PM
 * To change this template use File | Settings | File Templates.
 */
define(function() {
    return {
        applicationContextPath: null,
        reportcontexturl: "/servlets/reportcontext",
        reportoutputurl: "/servlets/reportoutput",
        reportactionurl: "/servlets/reportaction",
        reportcomponentsurl: "/servlets/reportcomponents",
        reportpagestatusurl: "/servlets/reportpagestatus"
    };
});