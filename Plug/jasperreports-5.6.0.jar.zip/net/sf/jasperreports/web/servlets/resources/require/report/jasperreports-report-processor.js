define(["jquery"], function($) {
    var ReportProcessor = function() {

    }

    ReportProcessor.prototype = {
        processReport: function(reportInstance) {
            // do something with reportInstance
        }
    };

    return ReportProcessor;
});
